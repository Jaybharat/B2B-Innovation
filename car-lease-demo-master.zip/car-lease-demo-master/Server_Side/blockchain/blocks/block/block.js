var read = require(__dirname+'/CRUD/read.js');
exports.read = read.read;
